sub source {
    local($file) = @_;
    local($return) = 0;

    $return = do $file;
    die "couldn't do \"$file\": $!" unless defined $return;
    die "couldn't parse \"$file\": $@" if $@;
    die "couldn't run \"$file\"" unless $return;
}
